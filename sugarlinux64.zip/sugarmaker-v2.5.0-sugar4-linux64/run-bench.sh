./sugarmaker -a YespowerSugar --benchmark -t1 -q
